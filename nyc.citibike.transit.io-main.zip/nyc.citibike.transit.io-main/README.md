# final_project_proposal

# Key NYC COVID Dates
https://www.investopedia.com/historical-timeline-of-covid-19-in-new-york-city-5071986


3/1/2020 - first case in NY state 
3/8/2020 - NYC issues guidelines to avoid densely packed buses, subways, or trains
3/16/2020 - NYC public schools close
3/17/2020 - NYC bars and restaurants close, except for delivery

4/30/2020 - Governor Cuomo announces NYC subway closures from 1 a.m. to 5 a.m.

6/8/2020 - NYC begins Phase 1 reopening
6/22/2020 - NYC begins Phase 2 reopening

7/6/2020 - NYC begins Phase 3 of reopening, without indoor dining
7/19/2020 - NYC begins Phase 4 reopening, excluding malls, museums and indoor dining/bars

9/29/2020 - Elementary students return to public school classrooms across NYC

11/19/2020 - NYC schools switch to all-remote
